<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1.0" />
  <meta name="theme-color" content="#0b1d35" />
  <title>NSJR Inc. Plumbing | Same-Day Plumbing Services in Lynbrook &amp; Nassau County, NY</title>
  <meta name="description" content="NSJR Inc. Plumbing offers licensed, insured plumbing services in Lynbrook &amp; Nassau County, NY. Drain cleaning, pipe repair, emergency plumbing, water heaters &amp; more. Same-day service, upfront pricing, 24/7 availability." />
  <meta name="keywords" content="plumber Lynbrook NY, drain cleaning Nassau County, emergency plumber Lynbrook, pipe repair Nassau County, water heater installation, plumbing services Long Island, NSJR Inc. plumbing" />
  <meta name="author" content="NSJR Inc. Plumbing" />
  <meta name="robots" content="index,follow" />
  <link rel="canonical" href="https://www.mydraindr.com/" />
  <meta property="og:type" content="website" />
  <meta property="og:title" content="NSJR Inc. Plumbing | Expert Plumbing &amp; Drain Services" />
  <meta property="og:description" content="Fast, reliable plumbing for New York. Licensed &amp; insured. 24/7 emergency service. Upfront pricing, no hidden fees." />
  <meta property="og:url" content="https://www.mydraindr.com/" />
  <meta property="og:image" content="https://www.mydraindr.com/images/og-image.jpg" />
  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:title" content="NSJR Inc. Plumbing | Expert Plumbing Services" />
  <meta name="twitter:description" content="Fast, reliable plumbing for New York. Licensed &amp; insured. 24/7 emergency service." />
  <meta name="twitter:image" content="https://www.mydraindr.com/images/twitter-image.jpg" />
  <script type="application/ld+json">{"@context":"https://schema.org","@type":"Plumber","name":"My Drain DR","url":"https://www.mydraindr.com","telephone":"+15168879687","address":{"@type":"PostalAddress","streetAddress":"Lynbrook","addressLocality":"Lynbrook","addressRegion":"NY","postalCode":"11563","addressCountry":"US"},"openingHours":"Mo-Sa 07:00-20:00","aggregateRating":{"@type":"AggregateRating","ratingValue":"4.9","reviewCount":"624"}}</script>
  <?php include 'components/head.php'; ?>
</head>
<body>
  <?php include 'components/navbar.php'; ?>
  <!-- HERO -->
  <section class="hero" aria-labelledby="hero-h">
    <div class="hero-dots" aria-hidden="true"></div>
    <div class="hero-glow" aria-hidden="true"></div>
    <div class="container">
      <div class="hero-inner">
        <div>
          <div class="hero-badge"><i class="fa-solid fa-star"></i>New construction, additions bathrooms and renovations</div>
          <h1 id="hero-h">Fast, Reliable<br><span class="h1-accent">Plumbing</span> You Can<br><span
              class="h1-sky">Trust.</span></h1>
          <p class="hero-desc">Proudly Based in Lynbrook — Serving the Communities We Live In
            NSJR Inc. is proudly based in Lynbrook, and we take pride in serving the same Nassau County communities we
            live in every
            day.</p>
          <div class="hero-actions">
            <a href="pages/contact.html" class="btn btn-amber btn-lg"><i class="fa-solid fa-clipboard-list"></i>Get Free
              Quote</a>
            <a href="tel:+15168879687" class="btn btn-outline btn-lg"><i class="fa-solid fa-phone"></i>Call Now</a>
          </div>

          <!-- St. Johns Electric Partner Strip -->
          <div class="electric-strip reveal"
            style="display:flex;align-items:center;gap:14px;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.12);border-radius:14px;padding:13px 18px;margin-top:6px;backdrop-filter:blur(6px);max-width:460px;">
            <div
              style="width:40px;height:40px;flex-shrink:0;border-radius:10px;background:linear-gradient(135deg,#1560bd,#2993d1);display:flex;align-items:center;justify-content:center;font-size:1.1rem;color:#f5c842;">
              ⚡</div>
            <div style="flex:1;min-width:0;">
              <div
                style="font-size:.7rem;font-weight:700;letter-spacing:.09em;color:rgba(255,255,255,.5);text-transform:uppercase;">
                Proud Partner</div>
              <div style="font-size:.87rem;font-weight:700;color:#fff;margin-top:2px;line-height:1.3;">Electrical
                Services by <span style="color:#f5c842;">St. Johns Electric</span> 
                <div style="color:rgba(255,255,255,.45);font-weight:400;margin-top:2px;line-height:1.3;">we offer full electrical services thru st. Johns Electric. Whether you have a dripping faucet or faulty outlet. We got you covered !</div></div>
            </div>
            <a href="https://stjohnselectric.com" target="_blank" rel="noopener"
              style="flex-shrink:0;font-size:.78rem;font-weight:700;color:#f5c842;text-decoration:none;white-space:nowrap;border:1px solid rgba(245,200,66,.35);border-radius:8px;padding:6px 12px;transition:background .2s;"
              onmouseover="this.style.background='rgba(245,200,66,.15)'" onmouseout="this.style.background=''">Visit
              Site <i class="fa-solid fa-arrow-up-right" style="font-size:.65rem;"></i></a>
          </div>

          <div class="hero-proof">
            <!-- STATS  
            <div>
              <div class="hero-stat-num"><span data-count="4800" data-suffix="+">0+</span></div>
              <div class="hero-stat-label">Jobs Completed</div>
            </div>
            <div>
              <div class="hero-stat-num"><span data-count="16" data-suffix=" Yrs">0</span></div>
              <div class="hero-stat-label">In Business</div>
            </div>-->
            <div>
              <div class="hero-stat-num">4.9<span class="accent">★</span></div>
              <div class="hero-stat-label">Average Rating</div>
            </div>
            <div>
              <div class="hero-stat-num">24/7</div>
              <div class="hero-stat-label">Emergency Line</div>
            </div>
          </div>
        </div>
        <div class="quote-card reveal">
          <div class="quote-card-head">
            <div class="qc-icon"><i class="fa-solid fa-calculator"></i></div>
            <div>
              <h3>Get a Free Estimate</h3>
              <p></p>
            </div>
          </div>
          <form id="quoteForm" novalidate style="display:flex;flex-direction:column;gap:14px;">
            <div class="form-row">
              <div class="form-group"><label for="qname">Your Name *</label><input class="form-control" id="qname"
                  type="text" placeholder="John Smith" required /></div>
              <div class="form-group"><label for="qphone">Phone Number *</label><input class="form-control" id="qphone"
                  type="tel" placeholder="(555) 000-0000" required /></div>
            </div>
            <div class="form-group"><label for="qemail">Email Address <span
                  style="font-size:.75rem;color:var(--gray3);">(get auto-confirmation)</span></label><input
                class="form-control" id="qemail" type="email" placeholder="john@email.com" /></div>
            <div class="form-group">
              <label for="qservice">Service Needed</label>
              <select class="form-control" id="qservice" required>
                <option value="">Choose a service…</option>
                <option>Drain Cleaning</option>
                <option>Pipe Repair / Replacement</option>
                <option>Emergency Plumbing</option>
                <option>Water Heater Service</option>
                <option>Sewer Line</option>
                <option>Toilet / Fixture Repair</option>
                <option>Other</option>
              </select>
            </div>
            <div class="form-group"><label for="qmsg">Describe the Issue</label><textarea class="form-control" id="qmsg"
                rows="3" placeholder="Briefly describe what's happening…"></textarea></div>
            <div id="quoteFormMsg"
              style="display:none;border-radius:10px;padding:12px 14px;font-size:.85rem;font-weight:600;"></div>
            <button type="submit" class="btn btn-primary btn-block" id="quoteSubmitBtn">Get Free Quote <i
                class="fa-solid fa-arrow-right"></i></button>
            <p style="font-size:.75rem;color:var(--gray3);text-align:center;"><i class="fa-solid fa-lock"></i> No spam.
              No commitment. 100% free.</p>
          </form>
          <script>
            (function () {
              var form = document.getElementById('quoteForm'), btn = document.getElementById('quoteSubmitBtn'), msg = document.getElementById('quoteFormMsg');
              form.addEventListener('submit', function (e) {
                e.preventDefault();
                if (!form.checkValidity()) { form.reportValidity(); return; }
                btn.disabled = true; btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Sending…';
                msg.style.display = 'none';
                var name = document.getElementById('qname').value.trim().split(' ');
                fetch('/api/inquiry.php', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    source: 'homepage',
                    first_name: name[0] || '', last_name: name.slice(1).join(' ') || '',
                    phone: document.getElementById('qphone').value,
                    email: document.getElementById('qemail').value,
                    service: document.getElementById('qservice').value,
                    message: document.getElementById('qmsg').value
                  })
                })
                  .then(function (r) { return r.json(); })
                  .then(function (d) {
                    if (d.ok) {
                      msg.style.background = '#f0fdf4'; msg.style.color = '#166534'; msg.style.border = '1px solid #bbf7d0';
                      msg.innerHTML = '<i class="fa-solid fa-circle-check"></i> ' + d.message;
                      msg.style.display = 'block'; form.reset();
                      btn.innerHTML = '<i class="fa-solid fa-circle-check"></i> Sent!';
                      btn.style.background = '#1a9e5e';
                      setTimeout(function () { btn.innerHTML = 'Get Free Quote <i class="fa-solid fa-arrow-right"></i>'; btn.disabled = false; btn.style.background = ''; }, 5000);
                    } else {
                      msg.style.background = '#fff5f4'; msg.style.color = '#9b1c1c'; msg.style.border = '1px solid #fecaca';
                      msg.innerHTML = '<i class="fa-solid fa-circle-exclamation"></i> ' + (d.message || 'Error. Please call us directly.');
                      msg.style.display = 'block'; btn.disabled = false; btn.innerHTML = 'Get Free Quote <i class="fa-solid fa-arrow-right"></i>';
                    }
                  })
                  .catch(function () {
                    msg.style.background = '#fff5f4'; msg.style.color = '#9b1c1c'; msg.style.border = '1px solid #fecaca';
                    msg.innerHTML = '<i class="fa-solid fa-circle-exclamation"></i> Connection error. Please call <a href="tel:+15168879687" style="color:#9b1c1c;">516-887-9687</a>';
                    msg.style.display = 'block'; btn.disabled = false; btn.innerHTML = 'Get Free Quote <i class="fa-solid fa-arrow-right"></i>';
                  });
              });
            })();
          </script>
        </div>
      </div>
    </div>
  </section>

  <!-- TRUST BAR -->
  <div class="trust-bar">
    <div class="container">
      <div class="trust-list">
        <!--
        <div class="trust-item"><i class="fa-solid fa-award"></i>
          <div><strong>Licensed &amp; Insured</strong><span>TX Lic. #PL-48821 · $2M Coverage</span></div>
        </div>
        <div class="trust-div" aria-hidden="true"></div> -->
        <div class="trust-item"><i class="fa-solid fa-star"></i>
          <div><strong>4.9 / 5 Rating</strong><span></span></div>
        </div>
        <div class="trust-div" aria-hidden="true"></div>
        <div class="trust-item"><i class="fa-solid fa-clock"></i>
          <div><strong>Same Day Response</strong><span>Emergency Guaranteed</span></div>
        </div>
        <div class="trust-div" aria-hidden="true"></div>
        <div class="trust-item"><i class="fa-solid fa-tag"></i>
          <div><strong>Upfront Pricing</strong><span>Zero Hidden Fees, Ever</span></div>
        </div>
        <div class="trust-div" aria-hidden="true"></div>
        <div class="trust-item"><i class="fa-solid fa-shield-halved"></i>
          <div><strong>1-Year Warranty</strong><span>For new service only</span></div>
        </div>
      </div>
    </div>
  </div>

  <!-- SERVICES -->
  <section class="section" aria-labelledby="svc-h">
    <div class="container">
      <div class="text-center mb-7">
        <div class="section-label"><i class="fa-solid fa-toolbox"></i>What We Do</div>
        <h2 id="svc-h">Plumbing Services That <span class="text-sky">Actually Fix</span> the Problem</h2>
        <p class="lead mt-4" style="max-width:500px;margin-left:auto;margin-right:auto;">Every service includes an
          upfront quote, licensed technicians, and a satisfaction guarantee.</p>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:24px;">

        <article class="card svc-card svc-card-blue reveal">
          <div class="svc-icon ic-blue">
            <i class="fa-solid fa-fire"></i>
          </div>

          <h3>Gas, Heating & Compliance Work</h3>

          <p>
            Gas pressure testing & certificates, gas meter restoration, plumbing violations correction,
            and complete boiler & heating system installations — all handled safely and professionally.
          </p>

          <a href="pages/services.html#gas" class="card-link">
            See Details <i class="fa-solid fa-arrow-right"></i>
          </a>
        </article>
        <article class="card svc-card svc-card-amber reveal">
          <div class="svc-icon ic-amber"><i class="fa-solid fa-faucet-drip"></i></div>
          <h3>Pipe Repair &amp; Replacement</h3>
          <p>Burst pipes, pinhole leaks, or corroded lines — we diagnose precisely and fix with lasting, code-compliant
            materials.</p><a href="pages/services.html#pipe" class="card-link">See Details <i
              class="fa-solid fa-arrow-right"></i></a>
        </article>
        <article class="card svc-card svc-card-red reveal">
          <div class="svc-icon ic-red"><i class="fa-solid fa-bolt"></i></div>
          <h3>24/7 Emergency Plumbing</h3>
          <p>Plumbing disasters don't wait. We arrive in 60 minutes or less — nights, weekends, holidays — no extra
            charges.</p><a href="pages/services.html#emergency" class="card-link">See Details <i
              class="fa-solid fa-arrow-right"></i></a>
        </article>
        <article class="card svc-card svc-card-purple reveal">
          <div class="svc-icon ic-amber"><i class="fa-solid fa-fire-flame-curved"></i></div>
          <h3>Water Heater Services</h3>
          <p>Installation, repair, and energy-efficient tankless upgrades. Never wake up to a cold shower again.</p><a
            href="pages/services.html#heater" class="card-link">See Details <i class="fa-solid fa-arrow-right"></i></a>
        </article>
        <article class="card svc-card svc-card-green reveal">
          <div class="svc-icon ic-green"><i class="fa-solid fa-arrow-down"></i></div>
          <h3>Sewer Line Services</h3>
          <p>Camera inspection, trenchless repair, and full replacement — done cleanly without destroying your yard.</p>
          <a href="pages/services.html#sewer" class="card-link">See Details <i class="fa-solid fa-arrow-right"></i></a>
        </article>
        <article class="card svc-card svc-card-teal reveal">
          <div class="svc-icon ic-teal"><i class="fa-solid fa-toilet"></i></div>
          <h3>Toilet &amp; Fixture Repair</h3>
          <p>Running toilets, leaky faucets, broken fixtures — quick clean repairs that save water and stop the
            frustration.</p><a href="pages/services.html" class="card-link">See Details <i
              class="fa-solid fa-arrow-right"></i></a>
        </article>
      </div>
      <div class="text-center mt-6 reveal"><a href="pages/services.html" class="btn btn-ghost btn-lg"><i
            class="fa-solid fa-list"></i>View All Services</a></div>
    </div>
  </section>

  <!-- HOW IT WORKS -->
  <section class="section bg-off" aria-labelledby="how-h">
    <div class="container">
      <div class="grid-2">
        <div>
          <div class="section-label reveal"><i class="fa-solid fa-list-ol"></i>Simple Process</div>
          <h2 id="how-h" class="reveal">How It Works — <span class="text-sky">3 Easy Steps</span></h2>
          <p class="lead mt-4 mb-6 reveal">From your first call to a fully fixed problem — we make the experience smooth
            and stress-free.</p>
          <div style="display:flex;flex-direction:column;gap:28px;">
            <div class="step reveal step-sky">
              <div class="step-num">1</div>
              <div class="step-body">
                <h4>Call or Book Online</h4>
                <p>Tell us what's happening. We'll ask a few quick questions and schedule your visit — often same day.
                </p>
              </div>
            </div>
            <div class="step reveal step-amber">
              <div class="step-num">2</div>
              <div class="step-body">
                <h4>We Diagnose &amp; Quote</h4>
                <p>Our tech arrives, inspects the issue, and gives you a clear upfront price. You approve before any
                  work starts.</p>
              </div>
            </div>
            <div class="step reveal step-green">
              <div class="step-num">3</div>
              <div class="step-body">
                <h4>Fixed Right — Guaranteed</h4>
                <p>We complete the repair cleanly and efficiently. Everything's covered by our 1-year labor warranty.
                </p>
              </div>
            </div>
          </div>
        </div>
        <div class="reveal stat-grid">
          <!--
          <div class="stat-card stat-card-light stat-card-sky">
            <div class="stat-num"><span data-count="4800" data-suffix="+">0+</span></div>
            <div class="stat-label">Jobs Done</div>
          </div>
          <div class="stat-card stat-card-light stat-card-amber" style="margin-top:24px;">
            <div class="stat-num"><span data-count="98" data-suffix="%">0%</span></div>
            <div class="stat-label">Satisfaction Rate</div>
          </div>
          <div class="stat-card stat-card-light stat-card-green" style="margin-top:-24px;">
            <div class="stat-num"><span data-count="16" data-suffix="">0</span></div>
            <div class="stat-label">Years Experience</div>
          </div>
          <div class="stat-card stat-card-light stat-card-purple">
            <div class="stat-num"><span data-count="624" data-suffix="+">0+</span></div>
            <div class="stat-label">5-Star Reviews</div>
          </div>-->
        </div>
      </div>
    </div>
  </section>

  <!-- WHY US -->
  <section class="section" aria-labelledby="why-h">
    <div class="container">
      <div class="text-center mb-7 reveal">
        <div class="section-label"><i class="fa-solid fa-circle-check"></i>Why Choose Us</div>
        <h2 id="why-h">What Makes Us <span class="text-sky">Different</span></h2>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:20px;">
        <div class="reveal why-card why-card-amber"><i class="fa-solid fa-tag"
            style="font-size:1.8rem;color:var(--amber);margin-bottom:12px;display:block;"></i>
          <h4 class="mb-2">Upfront Pricing</h4>
          <p style="font-size:.88rem;">You see the full cost before we start. No surprise invoices.</p>
        </div>
        <div class="reveal why-card why-card-sky"><i class="fa-solid fa-calendar-day"
            style="font-size:1.8rem;color:var(--blue);margin-bottom:12px;display:block;"></i>
          <h4 class="mb-2">Same-Day Service</h4>
          <p style="font-size:.88rem;">Call before noon — we'll usually get there today.</p>
        </div>
        <div class="reveal why-card why-card-green"><i class="fa-solid fa-shield-halved"
            style="font-size:1.8rem;color:var(--green);margin-bottom:12px;display:block;"></i>
          <h4 class="mb-2">1-Year Warranty<p style="font-size:.68rem;">For new service only</p>
          </h4>
          <p style="font-size:.88rem;">Every repair is covered. If it fails, we come back free.</p>
        </div>
        <div class="reveal why-card why-card-sky"><i class="fa-solid fa-id-badge"
            style="font-size:1.8rem;color:var(--sky);margin-bottom:12px;display:block;"></i>
          <h4 class="mb-2">Vetted Technicians</h4>
          <p style="font-size:.88rem;">Background-checked, uniformed, and fully licensed.</p>
        </div>
        <!---
        <div class="reveal why-card why-card-sky"><i class="fa-solid fa-moon"
            style="font-size:1.8rem;color:var(--blue);margin-bottom:12px;display:block;"></i>
          <h4 class="mb-2">No Overtime Fees</h4>
          <p style="font-size:.88rem;">Nights, weekends, holidays — same price, always.</p>
        </div> -->

        <div class="reveal why-card why-card-green"><i class="fa-solid fa-leaf"
            style="font-size:1.8rem;color:var(--green);margin-bottom:12px;display:block;"></i>
          <h4 class="mb-2">Eco-Friendly Methods</h4>
          <p style="font-size:.88rem;">Water-safe products and efficient techniques throughout.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- REVIEWS -->
  <section class="section bg-off" aria-labelledby="rev-h">
    <div class="container">
      <div class="text-center mb-7 reveal">
        <div class="section-label"><i class="fa-solid fa-heart"></i>Real Reviews</div>
        <h2 id="rev-h">What Our Customers Say</h2>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:24px;">
        <article class="review-card reveal">
          <div class="review-stars">★★★★★</div>
          <p class="review-text">"NSJR Inc. Plumbing has been fast for months. The tech arrived within the hour, found a
            root
            intrusion, and cleared it completely. Best plumber experience I've ever had. Will use again."</p>
          <div class="review-author">
            <div class="review-avatar">SM</div>
            <div>
              <div class="review-name">Sandra Mitchell</div>
              <div class="review-loc"><i class="fa-solid fa-location-dot" style="font-size:.7rem;color:var(--sky);"></i>
                New York</div>
            </div>
          </div>
        </article>
        <article class="review-card reveal">
          <div class="review-stars">★★★★★</div>
          <p class="review-text">"Called at 2am with a burst pipe. They were at my door in 40 minutes. Saved my hardwood
            floors from serious damage. Professional, fast, and the price was completely fair."</p>
          <div class="review-author">
            <div class="review-avatar">JR</div>
            <div>
              <div class="review-name">James Rourke</div>
              <div class="review-loc"><i class="fa-solid fa-location-dot" style="font-size:.7rem;color:var(--sky);"></i>
                New York</div>
            </div>
          </div>
        </article>
        <article class="review-card reveal">
          <div class="review-stars">★★★★★</div>
          <p class="review-text">"Had a new tankless water heater installed. They explained everything, matched the
            exact quote, and the work was immaculate. Cut our energy bill noticeably. Highly recommend."</p>
          <div class="review-author">
            <div class="review-avatar">AL</div>
            <div>
              <div class="review-name">Angela Liu</div>
              <div class="review-loc"><i class="fa-solid fa-location-dot" style="font-size:.7rem;color:var(--sky);"></i>
                New York</div>
            </div>
          </div>
        </article>
      </div>
    </div>
  </section>

  <!-- CTA -->
  <section class="section">
    <div class="container">
      <div class="cta-box reveal">
        <div
          style="position:relative;z-index:2;display:flex;align-items:center;justify-content:space-between;gap:32px;flex-wrap:wrap;">
          <div>
            <div class="section-label"
              style="background:rgba(255,255,255,.1);color:rgba(255,255,255,.85);border-color:rgba(255,255,255,.15);"><i
                class="fa-solid fa-phone-flip"></i>Ready to Help</div>
            <h2 class="text-white mt-3" style="font-size:clamp(1.8rem,4vw,3rem);">Plumbing Problem?<br>Let's Fix It
              <span class="text-amber">Today.</span>
            </h2>
            <p style="color:rgba(255,255,255,.55);margin-top:10px;">Free estimates · No call-out fees · Satisfaction
              guaranteed</p>
          </div>
          <div style="display:flex;gap:14px;flex-wrap:wrap;">
            <a href="tel:+15168879687" class="btn btn-amber btn-lg"><i class="fa-solid fa-phone"></i>Call Now</a>
            <a href="pages/contact.html" class="btn btn-outline btn-lg"><i class="fa-solid fa-calendar-check"></i>Book
              Online</a>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- FOOTER -->

  <?php include 'components/footer.php'; ?>
</body>
</html>
